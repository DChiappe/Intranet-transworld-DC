process.env.TZ = 'America/Santiago';   // o 'America/Argentina/Buenos_Aires'


const express = require('express');
const path = require('path');
const session = require('express-session');
const expressLayouts = require('express-ejs-layouts');
require('dotenv').config();

const indexRoutes = require('./routes/index');
const procesosRoutes = require('./routes/procesos');
const personasRoutes = require('./routes/personas');
const sistemasRoutes = require('./routes/sistemas');
const marketingRoutes = require('./routes/marketing');
const authRoutes = require('./routes/auth'); // <-- nuevo

const app = express();
const PORT = process.env.PORT || 3000;

// Motor de vistas + layouts
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('layout', 'layout'); // usa views/layout.ejs por defecto

// Para leer datos de formularios <form method="POST">
app.use(express.urlencoded({ extended: true }));

// Sesiones
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'cambia-este-secreto',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 // 1 hora
    }
  })
);

// Hacer disponible el usuario en todas las vistas (si existe)
app.use((req, res, next) => {
  res.locals.usuario = req.session.user || null;
  next();
});

// Archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Middleware de protección
function requireAuth(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  return res.redirect('/login');
}

// Rutas de autenticación (NO protegidas)
app.use('/', authRoutes);

// Rutas principales (PROTEGIDAS)
app.use('/', requireAuth, indexRoutes);
app.use('/procesos', requireAuth, procesosRoutes);
app.use('/personas', requireAuth, personasRoutes);
app.use('/sistemas', requireAuth, sistemasRoutes);
app.use('/marketing', requireAuth, marketingRoutes);

// (Opcional) 404 al final
// app.use((req, res) => {
//   res.status(404).render('404', { titulo: 'Página no encontrada' });
// });

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});

// src/routes/sistemas.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /sistemas  → pestaña base
router.get('/', (req, res) => {
  res.render('sistemas/index', {
    titulo: 'Sistemas y Herramientas'
  });
});

// GET /sistemas/rex
router.get('/rex', (req, res) => {
  res.render('sistemas/rex', {
    titulo: 'Rex+'
  });
});

/* ===========================
   TICKETERA
   =========================== */

// GET /sistemas/ticketera → listado de tickets
router.get('/ticketera', (req, res) => {
  const sql = `
    SELECT id, titulo, categoria, prioridad, estado, fecha_creacion
    FROM tickets
    ORDER BY fecha_creacion DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error consultando tickets:', err);
      return res.status(500).send('Error consultando tickets');
    }

    res.render('sistemas/ticketera', {
      titulo: 'Ticketera',
      tickets: results
    });
  });
});

// GET /sistemas/ticketera/nuevo → formulario para crear ticket
router.get('/ticketera/nuevo', (req, res) => {
  res.render('sistemas/ticketera_nuevo', {
    titulo: 'Nuevo ticket',
    error: null,
    formData: {}
  });
});

// POST /sistemas/ticketera → recibir y guardar nuevo ticket
router.post('/ticketera', (req, res) => {
  const {
    titulo,
    descripcion,
    categoria,
    prioridad,
    solicitante_nombre,
    solicitante_email
  } = req.body;

  // ✅ Validación: todos los campos obligatorios
  if (
    !titulo ||
    !descripcion ||
    !categoria ||
    !prioridad ||
    !solicitante_nombre ||
    !solicitante_email
  ) {
    return res.status(400).render('sistemas/ticketera_nuevo', {
      titulo: 'Nuevo ticket',
      error: 'Por favor completa todos los campos antes de enviar el ticket.',
      formData: {
        titulo,
        descripcion,
        categoria,
        prioridad,
        solicitante_nombre,
        solicitante_email
      }
    });
  }

  const sql = `
    INSERT INTO tickets (titulo, descripcion, categoria, prioridad, solicitante_nombre, solicitante_email)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [titulo, descripcion, categoria, prioridad, solicitante_nombre, solicitante_email],
    (err, result) => {
      if (err) {
        console.error('Error creando ticket:', err);
        return res.status(500).send('Error creando ticket');
      }

      // Redirige al listado de tickets
      res.redirect('/sistemas/ticketera');
    }
  );
});

// GET /sistemas/ticketera/:id → detalle de un ticket
router.get('/ticketera/:id', (req, res) => {
  const { id } = req.params;

  const sql = `
    SELECT id, titulo, descripcion, categoria, prioridad, estado,
           solicitante_nombre, solicitante_email, fecha_creacion, fecha_actualizacion
    FROM tickets
    WHERE id = ?
  `;

  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Error obteniendo ticket:', err);
      return res.status(500).send('Error obteniendo ticket');
    }

    if (results.length === 0) {
      return res.status(404).send('Ticket no encontrado');
    }

    res.render('sistemas/ticketera_detalle', {
      titulo: `Ticket #${id}`,
      ticket: results[0]
    });
  });
});

// POST /sistemas/ticketera/:id/estado → actualizar estado del ticket
router.post('/ticketera/:id/estado', (req, res) => {
  const { id } = req.params;
  const { estado } = req.body; // 'Abierto', 'En progreso', 'Cerrado'

  const sql = `
    UPDATE tickets
    SET estado = ?
    WHERE id = ?
  `;

  db.query(sql, [estado, id], (err, result) => {
    if (err) {
      console.error('Error actualizando estado:', err);
      return res.status(500).send('Error actualizando estado');
    }

    res.redirect(`/sistemas/ticketera/${id}`);
  });
});


module.exports = router;
